import React from "react";

function Footer() {
  return (
    <>
    <div className="pt-3">
    <div className="bg-dark">
        <p className="text-white d-flex justify-content-center pt-3 pb-3 border border-warning">
          © 2024 - Pizzería Mamma Mia! - Todos los derechos reservados
        </p>
      </div>
    </div>
     
    </>
  );
}

export default Footer;
